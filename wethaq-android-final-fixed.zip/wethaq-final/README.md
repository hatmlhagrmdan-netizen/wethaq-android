# وَثاق

مشروع Android لتطبيق تواصل مستقل.

المؤسس: حاتم حسين الحاج رمضان

## البناء

- Android Gradle Plugin: 8.6.1
- Gradle: 8.7
- Kotlin: 2.0.21
- compileSdk / targetSdk: 35
- minSdk: 23
- Java / JVM target: 17

## GitHub Actions

يتم بناء Debug و Release تلقائيًا عند الدفع إلى `main` أو `master`، أو عند تشغيل Workflow يدويًا.

الناتج يظهر في Artifacts باسم `wethaq-apks`.
