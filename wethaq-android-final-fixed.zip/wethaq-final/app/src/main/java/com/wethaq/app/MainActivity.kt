package com.wethaq.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.rgb(16, 19, 26))
        }

        val logo = TextView(this).apply {
            text = "وَثاق"
            textSize = 42f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }

        val description = TextView(this).apply {
            text = "منصة تواصل مستقلة\nالمؤسس: حاتم حسين الحاج رمضان"
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, 24, 0, 40)
        }

        val name = EditText(this).apply {
            hint = "الاسم الثلاثي"
            textSize = 18f
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            gravity = Gravity.RIGHT
        }

        val enter = Button(this).apply {
            text = "الدخول إلى وَثاق"
            textSize = 17f
            isAllCaps = false
        }

        enter.setOnClickListener {
            val value = name.text.toString().trim()
            val parts = value.split(Regex("\\s+")).filter { it.isNotBlank() }

            if (parts.size < 3) {
                name.error = "أدخل الاسم الثلاثي"
                name.requestFocus()
                return@setOnClickListener
            }

            Toast.makeText(
                this,
                "مرحبًا بك في وَثاق، $value",
                Toast.LENGTH_LONG
            ).show()
        }

        root.addView(logo, matchWrap())
        root.addView(description, matchWrap())
        root.addView(name, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 60))
        root.addView(enter, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 60))

        setContentView(root)
    }

    private fun matchWrap(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
}
