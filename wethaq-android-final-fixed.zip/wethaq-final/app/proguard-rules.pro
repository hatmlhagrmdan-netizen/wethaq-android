# وَثاق - custom R8/ProGuard rules.
# Keep this file in the project so release builds have a valid rules file.
