package com.wethaq.app
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(32,32,32,32);setBackgroundColor(Color.rgb(16,19,26))}
  val logo=TextView(this).apply{text="وَثاق";textSize=42f;gravity=Gravity.CENTER;setTextColor(Color.WHITE)}
  val founder=TextView(this).apply{text="منصة تواصل مستقلة\nالمؤسس: حاتم حسين الحاج رمضان";textSize=17f;gravity=Gravity.CENTER;setTextColor(Color.LTGRAY);setPadding(0,24,0,40)}
  val name=EditText(this).apply{hint="الاسم الثلاثي";textSize=18f;setSingleLine();setTextColor(Color.WHITE);setHintTextColor(Color.GRAY);gravity=Gravity.RIGHT}
  val enter=Button(this).apply{text="الدخول إلى وَثاق";textSize=17f}
  enter.setOnClickListener{val n=name.text.toString().trim();if(n.split(" ").filter{it.isNotBlank()}.size<3)name.error="أدخل الاسم الثلاثي" else Toast.makeText(this,"مرحبًا بك في وَثاق، $n",Toast.LENGTH_LONG).show()}
  root.addView(logo,LinearLayout.LayoutParams(-1,-2));root.addView(founder,LinearLayout.LayoutParams(-1,-2));root.addView(name,LinearLayout.LayoutParams(-1,60));root.addView(enter,LinearLayout.LayoutParams(-1,60));setContentView(root)
 }
}
